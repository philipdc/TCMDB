var oeTags = '<img src="animation_media/animation.gif" width="1920" height="1080" alt=""/>';         
document.write( oeTags );
